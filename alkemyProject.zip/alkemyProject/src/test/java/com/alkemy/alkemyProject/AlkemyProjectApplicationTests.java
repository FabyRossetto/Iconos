package com.alkemy.alkemyProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlkemyProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
