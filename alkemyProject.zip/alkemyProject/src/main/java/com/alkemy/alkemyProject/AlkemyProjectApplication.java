package com.alkemy.alkemyProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlkemyProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlkemyProjectApplication.class, args);
	}

}
